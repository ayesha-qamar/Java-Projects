package th1;
/**
 * @author Ayesha Qamar
 */
public class WorkHard
{
   public double value1;
   public double value2;
   public double value3;

   public void outputSumNums ()
   {
      double sum = this.value1 + this.value2 + this.value3;
      System.out.println("The sum of " + this.value1 + ", " + this.value2 + " & " + this.value3 + " is " + sum);
   }

   public double returnSumNums ()
   {
      double sum = this.value1 + this.value2 + this.value3;
      return sum;
   }

   public void outputAve ()
   {
      double average = (this.value1 + this.value2 + this.value3) / 3;
      System.out.println("The average of " + this.value1 + ", " + this.value2 + " & " + average);
   }

   public double getAve ()
   {
      double average = (this.value1 + this.value2 + this.value3) / 3;
      return average;
   }

   public void shout (String sentence)
   {
      String sent = sentence.toUpperCase();
      System.out.println(sent);
   }

   public String returnShout (String sentence)
   {
      String sent = sentence.toUpperCase();
      return sent;
   }
}
