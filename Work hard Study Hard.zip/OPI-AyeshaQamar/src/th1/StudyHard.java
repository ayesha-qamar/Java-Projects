package th1;
/**
 * @author Ayesha Qamar
 */
public class StudyHard
{
   public static void main (String[] args)
   {
      WorkHard p1 = new WorkHard();
      p1.value1 = 5.0;
      p1.value2 = 3.0;
      p1.value3 = 8.0;
      p1.outputSumNums();
      System.out.println("The returned sum is " + p1.returnSumNums());
      p1.outputAve();
      System.out.println("The returned average is " + p1.getAve());
      p1.shout("Ma namey Jeff!");
      System.out.println(p1.returnShout("Ma namey Jeff!"));
   }
}
