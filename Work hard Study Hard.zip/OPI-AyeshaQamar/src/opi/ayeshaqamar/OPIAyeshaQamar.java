package opi.ayeshaqamar;

/**
 *
 * @author Rich Smith at ZenOfProgramming.com
 */
public class OPIAyeshaQamar 
{
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        
    }
}
