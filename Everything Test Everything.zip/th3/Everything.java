package th3;
import java.util.Random;
/**
 * @author Ayesha Qamar
 */
public class Everything
{
   private int countBy;
   private String name;

   public void setName (String name)
   {
      this.name = name;
   }

   public String getName ()
   {
      return this.name;
   }

   public Everything (String setName)
   {
      setName(setName);
   }

   public Everything ()
   {
   }

   public void setCountBy (int countBy) throws Exception
   {
      if (countBy < 1 || countBy > 5) {
         Exception err = new Exception("The number must be between 1 and 5");
         throw err;
      }
      this.countBy = countBy;
   }

   public int getCountBy ()
   {
      return this.countBy;
   }

   public String demoCounting (int arg1, int arg2)
   {
      String message = "";
      if (arg1 < arg2) {
         for (int i = arg1; i < arg2; i += this.countBy) {
            message += i + " ,";
         }
      }
      for (int i = arg1; i > arg1; i -= this.countBy) {
         message += i + " ,";
      }
      return message;
   }

   public String demoOverload (int arg)
   {
      String output = "";
      for (int i = 0; i < arg; i++) {
         output += "*";
      }
      return output;
   }

   public String demoOverload (int arg1, String arg2)
   {
      for (int i = 0; i < arg1; i++) {
         arg2 += arg2;
      }
      return arg2;
   }

   public String coinFlip (int arg)
   {
      Random rnd = new Random();
      int num1 = 0;
      String output1 = "";
      String output2 = "";
      for (int i = 0; i < arg; i++) {
         int flip = rnd.nextInt(2);
         if (flip == 0) {
            num1++;
         }
         output1 = "Heads: " + num1;
         int num2 = arg - num1;
         output2 = "Tails:" + num2;
      }
      String message = output1 + "\n" + output2;
      return message;
   }
}
