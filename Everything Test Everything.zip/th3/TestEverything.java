package th3;
import java.util.Scanner;
/**
 * @author Ayesha Qamar
 */
public class TestEverything
{
   public static void main (String[] args) throws Exception
   {
      Scanner scan = new Scanner(System.in);
      System.out.println("Please enter your name: ");
      String name = scan.nextLine();
      Everything ref1 = new Everything(name);
      System.out.println(ref1.getName());
      ref1.setCountBy(3);
      try {
         ref1.setCountBy(-5);
      }
      catch (Exception err) {
         System.out.println("Oops, can not count by a negative number" + err.getMessage());
      }
      System.out.println(ref1.demoCounting(10, 30));
      System.out.println(ref1.demoCounting(30, 10));
      System.out.println(ref1.demoOverload(14, "$"));
      System.out.println(ref1.demoOverload(3));
      System.out.println(ref1.coinFlip(10000));

   }
}
