
public class Card {
		String suit;
		int rank;
}
