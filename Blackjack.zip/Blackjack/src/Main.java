
public class Main {

	public static void main(String[] args) {
		BlackjackV1 b = new BlackjackV1();
		b.play();
		

	}

}
